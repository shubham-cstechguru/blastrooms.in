<sitemapindex xmlns="http://www.sitemap.org/schemas/sitemap/0.9">
    <sitemap>
        <loc>https://www.blastrooms.in/sitemap.xml/product</loc>
    </sitemap>
    <sitemap>
        <loc>https://www.blastrooms.in/sitemap.xml/category</loc>
    </sitemap>
    <sitemap>
        <loc>https://www.blastrooms.in/sitemap.xml/blog</loc>
    </sitemap>
    <sitemap>
        <loc>https://www.blastrooms.in/sitemap.xml/page</loc>
    </sitemap>
</sitemapindex>